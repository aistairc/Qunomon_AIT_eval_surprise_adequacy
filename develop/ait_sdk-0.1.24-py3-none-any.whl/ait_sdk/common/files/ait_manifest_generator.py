# Copyright © 2019 National Institute of Advanced Industrial Science and Technology （AIST）. All rights reserved.
# !/usr/bin/env python3.6
# coding=utf-8
from typing import List
import json
import re
from pathlib import Path

from ...utils.logging import log, get_logger


logger = get_logger()


class AITManifestGenerator:
    """
    ait.manifest.jsonを出力するためのクラス。
    set関数で各項目を入力し、write関数でjsonを出力する。

    Class for outputting ait.manifest.json.
    Input each item with the set function and output json with the write function.
    """

    def __init__(self, base_dir: str):
        """
        コンストラクタ

        Constructor

        Args:
            base_dir (str) :
                ait.manifest.json出力先のフォルダを指定する

                Specify the destination folder for ait.manifest.json output

        """

        self._ait_name = ""
        self._ait_description = ""
        self._ait_source_repository = ""
        self._ait_version = ""
        self._ait_quality = ""
        self._ait_keywords = []
        self._ait_references = []
        self._ait_licenses = []
 
        self._ait_inventories = []
        self._ait_parameters = []
        self._ait_measures = []
        self._ait_resources = []
        self._ait_downloads = []

        self._output_file_path = f'{base_dir}/ait.manifest.json'

    @log(logger)
    def set_ait_name(self, name: str) -> None:
        """
        name項目を設定する。

        名称自由に決めていただいて結構ですが、一意制約があるため以下の命名規則に沿って定義することを推奨します。

        Set the name item.

        You can use any name you want, but it is recommended to define it according to the following naming conventions because of the unique restriction.

        * `{prefix}_{target}_{task}_{format}_{measure}`
            * [必須]prefix: AITのタイプを表します。いくつかの予約されたタイプがあります。
                * eval : 品質評価
                * alyz : 分析
                * misc : その他
                * generate : AITに入力するデータを生成するAITに使います。
            * [必須]target: AITの評価対象によって"dataset"か"model"のいずれかを選択します。
            * [任意]task: AITの評価対象によって"dataset"か"model"のいずれかを選択します。
            * [任意]format: AITが取り扱うデータの形式
            * [任意]measure: AITで取り扱う品質特性

        * 制限
            * 名称は50文字以下にする必要があります
            * 利用可能な文字は、半角英数字 と `_` です

        Args:
            name (str)

        """

        self._ait_name = name

    @log(logger)
    def set_ait_description(self, description: str) -> None:
        """
        description項目を設定する。

        AIT利用者にとって選択の一助となるように、AITの算出する指標値について、
        導出式を記載することを推奨します。

        Set a description item.

        In order to help AIT users make a choice, the index values calculated by AIT should be
        It is recommended that the derivation formula be stated.

        Args:
            description (str)

        """

        self._ait_description = description

    @log(logger)
    def set_ait_source_repository(self, source_repository: str) -> None:
        """
        source_repository項目を設定する。

        Set the source_repository item.

        Args:
            source_repository (str)

        """

        self._ait_source_repository = source_repository

    @log(logger)
    def set_ait_version(self, version: str) -> None:
        """
        version項目を設定する。

        バージョンはメジャーバージョンとマイナーバージョンの組み合わせを推奨しますが、数値である必要はなく、
        それぞれが管理可能な体系としてください。

        Set the version item.

        Versions should be a combination of major and minor versions, but they do not have to be numeric.
        Each should be a manageable system.

        * {major_version}_{minor_version}

        Args:
            version (str)
        """

        self._ait_version = version

    @log(logger)
    def set_ait_quality(self, quality: str) -> None:
        """
        quality項目を設定する。
        QualityはURLで表現されます。

        Set the quality item.
        Quality is expressed as a URL.

        Args:
            quality (str)
        """

        self._ait_quality = quality

    @log(logger)
    def add_ait_keywords(self, keyword: str) -> None:
        """
        keywords項目を設定する。

        Set the keywords item.

        Args:
            keyword (str)

        """

        self._ait_keywords.append(keyword)

    @log(logger)
    def add_ait_references(self, bib_info: str, additional_info: str = '', url: str = '') -> None:
        """
        references項目を設定する。
        AITの根拠となる論文参照を記載します。

        Establish a references item.
        Describe the paper references as the basis for the AIT.

        Args:
            bib_info (str) :
            additional_info (str) :
            url (str)
        """

        reference = {'bib_info': bib_info}

        if len(additional_info) > 0: reference['additional_info'] = additional_info
        if len(url) > 0: reference['url'] = url

        self._ait_references.append(reference)

    @log(logger)
    def add_ait_licenses(self, license: str) -> None:
        """
        licenses項目を設定する。

        Set the licenses item.

        Args:
            license (str)

        """

        self._ait_licenses.append(license)

    # inventories
    @log(logger)
    def add_ait_inventories(self, 
                            name: str, 
                            type_: str, 
                            description: str, 
                            requirement: str,
                            depends_on_parameter: str = '') -> None:
        """
        inventories項目を設定する。
        format_ait_inventory_requirementメソッドでrequirementの事前設定が必要。

        Set the inventories item.　
        requirement must be preset with format_ait_inventory_requirement method.

        Args:
            name (str) 
            type_ (str) :
                以下いずれかの値である必要があります。

                It should be one of the following values

                    dataset
                    executable_model
                    model
                    attribute set

            description (str)
            requirement (str) :
                アセットが従うべき要件

                Requirements for assets
                    format_ (List)
                    compatible_packages (List) 
                    additional_info (str)
                    min (str)
                    max (str)
            depends_on_parameter (str) :
                本項目を有効化する依存パラメータ名を設定します。（任意）
                依存パラメータが未設定の場合、本項目は無効となります。
                未設定の場合、常に有効となります。

                Set the name of the dependent parameter to enable this item. (Optional)
                If the dependent parameter is not set, this item is disabled.
                If not set, this item is always enabled.
        """

        inventory = {'name': name,
                     'type': type_,
                     'description': description,
                     'requirement': requirement}
        
        if len(depends_on_parameter) > 0:
            if depends_on_parameter not in [params['name'] for params in self._ait_parameters]:
                raise KeyError(f'depends_on_parameter:{depends_on_parameter} is not defined.')
            else:
                inventory['depends_on_parameter'] = depends_on_parameter

        self._ait_inventories.append(inventory)

    # requirement
    @log(logger)
    def format_ait_inventory_requirement(self, 
                                         format_: list, 
                                         compatible_packages: list = [], 
                                         additional_info: list = [],
                                         min: str = '',
                                         max: str = ''):
        """
        inventoryのrequirement項目を設定する。
        create_inv_req_compatible_packagesメソッドでcompatible_packagesのitemを追加およびフォーマット。
        create_inv_req_additional_infoメソッドでadditional_infoのitemを追加およびフォーマット。

        Set the inventory requirement item.
        Add and format compatible_packages item with the create_inv_req_compatible_packages method.
        Add and format additional_info item with the create_inv_req_additional_info method.

        Args:
            format_ (List)
            compatible_packages (List) :
                アセットの準備・生成に必要とする／依存するソフトウェアの一覧。（任意）

                List of software required or dependent for asset preparation or generation. (Optional)
                    name (str)
                    version (str)
                    additional_info (str)
            additional_info (list) :
                任意

                Optional
            min (str) :
                inventoryのファイル数の最小値を設定します。（任意）

                Set the minimum value. (optional)

            max (str) :
                inventoryのファイル数の最大値を設定します。（任意）

                Set the maximum value. (optional)
        """

        requirement = {'format': format_}

        if len(compatible_packages) > 0: requirement['compatible_packages'] = compatible_packages
        if len(additional_info) > 0: requirement['additional_info'] = additional_info

        if len(min) > 0: 
            if self._is_positive_natural_number(min):
                requirement['min'] = min
            else:
                raise ValueError(f'inventory_requirement_min:{min} is not positive natural number type.')

        if len(max) > 0: 
            if self._is_positive_natural_number(max):
                requirement['max'] = max
            else:
                raise ValueError(f'inventory_requirement_max:{max} is not positive natural number type.')
        
        if len(min) > 0 and len(max) > 0:
            if int(min) > int(max):
                raise ValueError('inventory_requirement : max should be more than min.')

        return requirement
    
    # compatible_packages
    @log(logger)
    def create_inv_req_compatible_packages(self, 
                                           name: str, 
                                           version: str = '', 
                                           additional_info: str = ''):
        """
        inventoryのrequirementのcompatible_packages項目を設定する。

        Set the inventory requirement compatible_packages item.

        Args:
            name (str)
            version (str)
            additional_info (str)
        """

        compatible_package = {'name': name}

        if len(version) > 0: 
            compatible_package['version'] = version
        if len(additional_info) > 0: 
            compatible_package['additional_info'] = additional_info

        return compatible_package

    # model_info
    @log(logger)
    def create_inv_req_additional_info(self, 
                                       key: str, 
                                       value):
        """
        inventoryのrequirementのadditional_info項目を設定する。

        Set the inventory requirement additional_info item.

        Args:
            key (str)
                keyのサンプル
                    ・functionality : モデルが持つべき機能
                    ・tasks : モデルの想定タスク
                    ・component_type : モデル構成要素の種別
                    ・serialization_type : モデルのシリアライズ形式
                    ・input_formats : モデルの入力データのフォーマットに関する情報
                    ・output_shape : モデルの出力テンソル形状を記載する,サイズ不定の場合はNone, 次元数不定の場合はMultiDimと記載する
                    ・output_description : output_shapeで指定したshapeの各次元について捕捉説明を行う
               
               sample of key
                    ・functionality : functions that the model should have
                    ・tasks : task of the model
                    ・component_type : component type of the model
                    ・serialization_type : serialization type of the model
                    ・input_formats : information about the format of the model's input data
                    ・output_shape : describe the shape of the output tensor of the model
                                     if the size is unknown, write None
                                     if the number of dimensions is unknown, write MultiDim
                    ・output_description : provide a capture explanation for each dimension of the shape specified by output_shape

            value (String or array)
                valueのサンプル
                sample of value
                    ・functionality : enum 
                                        - inference
                                        - training
                                        - other
                    ・tasks : ['Image Classification', 'Object Detection']
                    ・component_type : enum
                                        - architecture
                                        - weights
                                        - hyperparameters
                                        - preprocessor
                    ・serialization_type : enum:
                                        - serialized
                                        - compiled
                                        - transpiled
                                        - source
                    ・input_formats : ['image', 'video', 'tabular', 'structured']
                    ・output_shape : ['None', '320', '240', 'MultiDim', '1']
                    ・output_description : ['batch_size', 'x-axis', 'y-axis', 'class_probability(multi-hot encoding)', 'confidence']
        """

        model_info_item = { key : value }

        return model_info_item

    # parameters
    @log(logger)
    def add_ait_parameters(self, name: str, 
                           type_: str, 
                           description: str, 
                           default_val: str = '', 
                           min_value: str = '', 
                           max_value: str = '', 
                           depends_on_parameter: str = '') -> None:
        """
        parameters項目を設定する。

        Set the parameters item.

        Args:
            name (str)
            type_ (str):
                以下いずれかの値である必要があります。

                It should be one of the following values

                    int
                    float
                    bool
                    str

            description (str)
            default_val (str):
                任意

                Optional

            min_value (str) :
                最小値を設定します。（任意）

                Set the minimum value. (optional)

            max_value (str) :
                最大値を設定します。（任意）

                Set the maximum value. (optional)

            depends_on_parameter (str) :
                本項目を有効化する依存パラメータ名を設定します。（任意）
                依存パラメータが未設定の場合、本項目は無効となります。
                未設定の場合、常に有効となります。

                Set the name of the dependent parameter to enable this item. (Optional)
                If the dependent parameter is not set, this item is disabled.
                If not set, this item is always enabled.
        """

        parameter = {'name': name, 'type': type_, 'description': description, 'default_val': default_val}

        if len(min_value) > 0:
            if self._is_numeric(min_value):
                parameter['min'] = min_value
            else:
                raise ValueError(f'parameters_min_value:{min_value} is not numeric type.')
            
        if len(max_value) > 0:
            if self._is_numeric(max_value):
                parameter['max'] = max_value
            else:
                raise ValueError(f'parameters_max_value:{max_value} is not numeric type.')
        
        if len(min_value) > 0 and len(max_value) > 0:
            if float(min_value) > float(max_value):
                raise ValueError('parameters : max should be more than min.')

        if len(depends_on_parameter) > 0:
            if depends_on_parameter not in [params['name'] for params in self._ait_parameters]:
                raise KeyError(f'depends_on_parameter:{depends_on_parameter} is not defined.')
            else:
                parameter['depends_on_parameter'] = depends_on_parameter

        self._ait_parameters.append(parameter)

    # measures
    @log(logger)
    def add_ait_measures(self, name: str, type_: str, description: str, structure: str, min: str = '', max: str = '') -> None:
        """
        measures項目を設定する。

        Set the measures item.

        Args:
            name (str)

            type_ (str):
                以下いずれかの値である必要があります。

                It should be one of the following values

                    int
                    float
                    bool
                    str

            description (str)

            structure (str) :
                以下いずれかの値である必要があります。

                It should be one of the following values

                    single
                    sequence

            min (str) :
                最小値を設定します。（任意）

                Set the minimum value. (optional)

            max (str) :
                最大値を設定します。（任意）

                Set the maximum value. (optional)
        """

        if len(min) > 0 and not self._is_numeric(min):
            raise ValueError(f'measures_min:{min} is not numeric type.')
        if len(max) > 0 and not self._is_numeric(max):
            raise ValueError(f'measures_max:{max} is not numeric type.')
        
        if len(min) > 0 and len(max) > 0:
            if float(min) > float(max):
                raise ValueError('measures : max should be more than min.')
            else:
                self._ait_measures.append({'name': name, 'type': type_, 'description': description, 'structure': structure, 'min':min, 'max':max})
        elif len(min) > 0 and len(max) == 0:
            self._ait_measures.append({'name': name, 'type': type_, 'description': description, 'structure': structure, 'min':min})
        elif len(min) == 0 and len(max) > 0:
            self._ait_measures.append({'name': name, 'type': type_, 'description': description, 'structure': structure, 'max':max})
        else:
            self._ait_measures.append({'name': name, 'type': type_, 'description': description, 'structure': structure})

    # resources
    @log(logger)
    def add_ait_resources(self, name: str, type_: str, description: str) -> None:
        """
        resources項目を設定する。

        Set the resources item.

        Args:
            name (str)

            type_ (str):

                以下いずれかの値である必要があります。

                It should be one of the following values

                    text
                    picture
                    table

            description (str)
        """

        self._ait_resources.append({'name': name, 'type': type_, 'description': description})

    # downloads
    @log(logger)
    def add_ait_downloads(self, name: str, description: str) -> None:
        """
        downloads項目を設定する。

        Set the downloads item.

        Args:
            name (str)
            description (str)
        """

        self._ait_downloads.append({'name': name, 'description': description})

    @log(logger)
    def _check_required_items(self) -> None:
        """
        必須項目のチェックを実施する

        Check the required fields

        Raises:
            ValueError:
                必須項目が存在しないときに発生する

                This occurs when a required field does not exist

        """

        check_general = {'ait_name': self._ait_name,
                         'ait_description': self._ait_description,
                         'ait_version': self._ait_version}
        for k, v in check_general.items():
            if len(v) == 0:
                raise ValueError(f'{k} is required.')

        if len(self._ait_references) > 0:
            for reference in self._ait_references: 
                if len(reference['bib_info']) == 0:
                    raise ValueError(f'references bib_info is required.') 

        self._check__required_item_section('inventories', self._ait_inventories)
        for inventory in self._ait_inventories: 
            if len(inventory['requirement']['format']) == 0:
                name = inventory['name']
                raise ValueError(f'{name} inventory format is required.')
        
        self._check__required_item_section('parameters', self._ait_parameters, ['default_val'])
        self._check__required_item_section('measures', self._ait_measures, ['min', 'max'])
        self._check__required_item_section('resources', self._ait_resources)
        self._check__required_item_section('downloads', self._ait_downloads)

    @staticmethod
    def _check__required_item_section(section_name, sections, skip_items=None):
        """
        必須項目の各セクションごとのチェックを実施する
        Conduct a check for each section of the required fields

        Args:
            section_name (str)
            sections (List)
            skip_items (List)

        Raises:
            ValueError:
                必須項目が存在しないときに発生する

                This occurs when a required field does not exist

        """

        for section in sections:
            name = section['name']
            for k, v in section.items():
                if (skip_items is not None) and (k in skip_items):
                    continue
                if len(v) == 0:
                    raise ValueError(f'{section_name}[{name}]/{k} is required.')

    @log(logger)
    def write(self) -> str:
        """
        設定した各項目をjsonファイルに出力する。
        書き込む前に必須チェック、フォーマットチェックを実施する。

        Output each set item to a json file.
        Before writing, perform the required checks and format checks.

        Raises:
            ValueError:
                必須項目が存在しないときに発生する

                This occurs when a required field does not exist
        
        Returns:
            出力先ファイルパス

            Output file path

        """

        self._check_required_items()

        self._check_format_items()

        output_json = {
            'name': self._ait_name,
            'description': self._ait_description,
            'source_repository': self._ait_source_repository,
            'version': self._ait_version,
            'quality': self._ait_quality,
            'keywords': self._ait_keywords,
            'references': self._ait_references,
            'licenses': self._ait_licenses
            }

        output_json['inventories'] = self._ait_inventories
        output_json['parameters'] = self._ait_parameters
        output_json['report'] = {}
        output_json['report']['measures'] = self._ait_measures
        output_json['report']['resources'] = self._ait_resources
        output_json['downloads'] = self._ait_downloads

        # 親フォルダ作成
        Path(self._output_file_path).parent.mkdir(parents=True, exist_ok=True)

        with open(self._output_file_path, 'w', encoding='utf-8') as f:
            json.dump(output_json, f, indent=2, ensure_ascii=False)

        return self._output_file_path

    @log(logger)
    def _check_format_items(self) -> None:
        """
        項目のフォーマットチェックを実施する

        Check the format of fields

        Raises:
            ValueError:
                フォーマットエラーのときに発生する

                This occurs when a format error occurs

        """

        # first character of name matches [0-9a-z]
        if not re.search('^[0-9a-z]', self._ait_name):
            raise ValueError(f'name:{self._ait_name} must start with [0-9] or [a-z]')
        # all characters of name matches [0-9], [a-z], [.], [-] and [_].
        if not re.fullmatch('[0-9a-z-_.]+', self._ait_name):
            raise ValueError(f'name:{self._ait_name} must be [0-9], [a-z], [.], [-] and [_].')

        docker_repository_name = self._ait_name
        if len(docker_repository_name) > 128:
            raise ValueError(f'{docker_repository_name} must be 128 characters or less.')

    @staticmethod
    def _is_positive_natural_number(value):
        """
        正整数形のチェック
        positive natural number type check

        Args:
            value (str)

        Returns:
            正整数形の場合:True
            正整数形ではない場合:False

            positive natural number type:True
            not positive natural number type:False
        """

        try:
            if int(value) >= 0:
                return True
            else:
                return False
        except ValueError:
            return False
            
    
    @staticmethod
    def _is_numeric(value):
        """
        numeric型のチェック
        numeric type check

        Args:
            value (str)

        Returns:
            numeric型の場合:True
            numeric型ではない場合:False

            numeric type:True
            not numeric type:False
        """

        try:
            float(value)
        except ValueError:
            return False
        else:
            return True